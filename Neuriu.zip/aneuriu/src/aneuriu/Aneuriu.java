
package aneuriu;

/**
 *
 * @author Ngorymilson
 */
public class Aneuriu {

    public static void main(String[] args) {
        janela a = new janela();
        a.setVisible(true);
    }
    
}
